# Soft Skills Simulation Scenarios

The complete library of 30 workplace‑conversation scenarios, plus the guidance on how to tweak their intensity, roles and context, is now hosted here on GitHub. Clone or download the repo to practise, adapt or extend the material as you wish. Pull requests and feedback are welcome.

```text
soft-skills-sim/
├── README.md
├── LICENSE
├── scenarios/
│   ├── S01.md
│   ├── …
│   └── S30.md
├── docs/
│   ├── Customising-Scenarios.md
│   └── Feedback-Template.md
└── CONTRIBUTING.md
```
