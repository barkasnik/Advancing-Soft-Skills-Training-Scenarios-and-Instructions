# Contributing

Feel free to open issues or pull requests with new scenarios or improvements.
